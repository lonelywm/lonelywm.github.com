#!/usr/bin/env python
# -*- coding:utf-8 -*-

from PyQt4 import QtCore,QtGui
from PyQt4.QtCore import Qt
from PyQt4.Qt import QEvent, QRect, QPoint

class DragProxy(QtCore.QObject):

    def __init__(self, parent):
        super(DragProxy,self).__init__()
        self.m_proxyTarget = parent
        
        #widgetRegion
        self.WR =['Top' ,'TopRight' ,'Right', 'RightBottom' ,'Bottom' ,'LeftBottom', 'Left'  ,'LeftTop' ,'Inner', 'Unknown']
        self.WRI = range(0,10)
        self.m_originPosGlobal = QPoint(0,0)
        self.m_originGeo = QRect(0,0,0,0)
        self.m_top = self.m_right = self.m_bottom = self.m_left = 0
        
        self.m_proxyTarget.setMouseTracking(True)
        self.m_proxyTarget.installEventFilter(self)
        
        self.m_regions = [QRect(0,0,0,0)]*9
        self.m_mousePressed = False
        self.m_regionPressed = self.WRI[9]
        self.m_moveAble = False
        self.m_moveAbleHeight = 30
      
        
    def SetMove(self, trueOrFalse ,height = 30):
        self.m_moveAble = trueOrFalse
        self.m_mousePressed = height
    
    
    def SetBorderWidth(self,top,right,bottom,left):
        self.m_top = top
        self.m_right = right
        self.m_bottom = bottom
        self.m_left = left
    
    
    def UpdateGeometry(self,x,y,w,h):
        minWidth = self.m_proxyTarget.minimumWidth()
        minHeight = self.m_proxyTarget.minimumHeight()
        maxWidth = self.m_proxyTarget.maximumWidth()
        maxHeight = self.m_proxyTarget.maximumHeight()
        if w<minWidth or w>maxWidth or h< minHeight or h> maxHeight:
            return
        self.m_proxyTarget.setGeometry(x,y,w,h)
        
    
    def HitTest(self,pos):
        for i in range(0,9):
            rect = self.m_regions[i]
            if rect.contains(pos):
                return i
        return self.WRI[9]
    
    
    def eventFilter(self,obj,event):
        eventType = event.type()
        if( eventType == QEvent.MouseMove):
            mouseEvent = event
            curPosLocal = mouseEvent.pos()
            regionType = self.HitTest(curPosLocal)
            curPosGlobal = self.m_proxyTarget.mapToGlobal(curPosLocal)
            
            if(not self.m_mousePressed):
                regionTypeStr = self.WR[regionType]
                if(regionTypeStr == "Top" or regionTypeStr =="Bottom"):
                    self.m_proxyTarget.setCursor(Qt.SizeVerCursor)
                elif(regionTypeStr == "TopRight" or regionTypeStr =="LeftBottom"):
                    self.m_proxyTarget.setCursor(Qt.SizeBDiagCursor)
                elif(regionTypeStr == "Right" or regionTypeStr =="Left"):
                    self.m_proxyTarget.setCursor(Qt.SizeHorCursor)
                elif(regionTypeStr == "RightBottom" or regionTypeStr =="LeftTop"):
                    self.m_proxyTarget.setCursor(Qt.SizeFDiagCursor)
                else:
                    self.m_proxyTarget.setCursor(Qt.ArrowCursor)
            else:
                regionPressedStr = self.WR[self.m_regionPressed]
                if(regionPressedStr == "Inner"):
                    if(self.m_moveAble == True):
                        if(curPosLocal.y()<self.m_moveAbleHeight):
                            self.m_proxyTarget.move(self.m_originGeo.topLeft() + curPosGlobal - self.m_originPosGlobal)
                elif(regionPressedStr == "Top"):
                    dY = curPosGlobal.y() - self.m_originPosGlobal.y()
                    self.UpdateGeometry(self.m_originGeo.x(),self.m_originGeo.y()+dY,self.m_originGeo.width(),self.m_originGeo.height()-dY)
                elif(regionPressedStr == "TopRight"):
                    dXY = curPosGlobal - self.m_originPosGlobal
                    self.UpdateGeometry(self.m_originGeo.x(),self.m_originGeo.y()+dXY.y(),self.m_originGeo.width()+dXY.x(),self.m_originGeo.height()-dXY.y())
                elif(regionPressedStr == "Right"):
                    dX = curPosGlobal.x() - self.m_originPosGlobal.x()
                    self.UpdateGeometry(self.m_originGeo.x(),self.m_originGeo.y(),self.m_originGeo.width()+dX,self.m_originGeo.height())
                elif(regionPressedStr == "RightBottom"):
                    dXY = curPosGlobal - self.m_originPosGlobal
                    self.UpdateGeometry(self.m_originGeo.x(),self.m_originGeo.y(),self.m_originGeo.width()+dXY.x(),self.m_originGeo.height()+dXY.y())
                elif(regionPressedStr == "Bottom"):
                    dY = curPosGlobal.y() - self.m_originPosGlobal.y()
                    self.UpdateGeometry(self.m_originGeo.x(),self.m_originGeo.y(),self.m_originGeo.width(),self.m_originGeo.height()+dY)
                elif(regionPressedStr == "LeftBottom"):
                    dXY = curPosGlobal - self.m_originPosGlobal
                    self.UpdateGeometry(self.m_originGeo.x()+dXY.x(),self.m_originGeo.y(),self.m_originGeo.width() - dXY.x(),self.m_originGeo.height() + dXY.y())
                elif(regionPressedStr == "Left"):
                    dX = curPosGlobal.x() - self.m_originPosGlobal.x()
                    self.UpdateGeometry(self.m_originGeo.x()+dX,self.m_originGeo.y(),self.m_originGeo.width()-dX,self.m_originGeo.height())
                elif(regionPressedStr == "LeftTop"):
                    dXY = curPosGlobal - self.m_originPosGlobal
                    self.UpdateGeometry(self.m_originGeo.x() + dXY.x(),self.m_originGeo.y()+dXY.y(),self.m_originGeo.width()-dXY.x(),self.m_originGeo.height()-dXY.y())
        elif(eventType == QEvent.MouseButtonPress):
            mouseEvent = event
            if(mouseEvent.button() == Qt.LeftButton):
                self.m_mousePressed = True
                curPos = mouseEvent.pos()
                self.m_regionPressed = self.HitTest(curPos)
                self.m_originPosGlobal = self.m_proxyTarget.mapToGlobal(curPos)
                self.m_originGeo = self.m_proxyTarget.geometry()
                
                

        elif(eventType == QEvent.MouseButtonRelease):
            self.m_mousePressed = False
            self.m_regionPressed = self.WRI[9] #Unknown
            self.m_proxyTarget.setCursor(Qt.ArrowCursor)
            
        elif(eventType == QEvent.Resize):
            self.MakeRegions()
            
        elif(eventType == QEvent.Leave):
            self.m_proxyTarget.setCursor(Qt.ArrowCursor)
            
        elif(eventType == QEvent.Resize):
            pass #timer

        

        return super(DragProxy,self).eventFilter(obj,event)
    
    
    def MakeRegions(self):
        width = self.m_proxyTarget.width()
        height = self.m_proxyTarget.height()
        
        self.m_regions[0] = QRect(self.m_left,0,width - self.m_left -self.m_right ,self.m_top)
        self.m_regions[1] = QRect(width - self.m_right,0,self.m_right,self.m_top)
        self.m_regions[2] = QRect(width -self.m_right,self.m_top,self.m_right,height - self.m_top-self.m_bottom)
        self.m_regions[3] = QRect(width -self.m_right,height -self.m_bottom,self.m_right,self.m_bottom)
        self.m_regions[4] = QRect(self.m_left,height-self.m_bottom,width-self.m_left-self.m_right,self.m_bottom)
        self.m_regions[5] = QRect(0,height-self.m_bottom,self.m_left,self.m_bottom)
        self.m_regions[6] = QRect(0,self.m_top,self.m_left,height -self.m_top-self.m_bottom)
        self.m_regions[7] = QRect(0,0,self.m_left,self.m_top)
        self.m_regions[8] = QRect(self.m_left,self.m_top,width - self.m_left-self.m_right,height -self.m_top-self.m_bottom)

                                            

# pro = DragProxy