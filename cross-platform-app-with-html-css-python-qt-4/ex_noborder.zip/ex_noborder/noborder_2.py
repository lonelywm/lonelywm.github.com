# -*- coding:utf-8 -*-

from PyQt4 import QtGui, QtWebKit, QtCore
import sys
import DragProxy
    
class myWindow(QtWebKit.QWebView):
    def __init__(self,app, parent=None):
        super(myWindow, self).__init__(parent)
        self.resize(400, 200)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.page().mainFrame().addToJavaScriptWindowObject("_myWindow", self)
        self.load(QtCore.QUrl('index.html'))
        self.app = app
    
    #最大化显示
    @QtCore.pyqtSlot()  
    def showMaxsize(self):
        print 1
        self.showMaximized()
    
    #最小化显示   
    @QtCore.pyqtSlot()
    def showMinsize(self):
        self.showMinimized()
    
    #普通大小显示  
    @QtCore.pyqtSlot()
    def showNormalsize(self):
        self.showNormal()
    
    #退出程序
    @QtCore.pyqtSlot()
    def appClose(self):
        app.quit()
    
if  __name__ == "__main__":
    
    app = QtGui.QApplication(sys.argv)
    main = myWindow(app)
    
    p = DragProxy.DragProxy(main)
    p.SetBorderWidth(4,4,4,4)
    p.SetMove(True)
    main.show()
    sys.exit(app.exec_())
