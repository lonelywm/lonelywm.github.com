\pgfmathtruncatemacro{\XValue}{mod(\x,3)}% //返回整数的数学解
\pgfmathsetmacro{\p}{1+ mod(\i+\j-1,\n)} 这个是错误的，好像pgfmathsetmacro是非整数


%-----------------------------------------
\begin{algorithm}[htb]   
\caption{初始化}   
\begin{algorithmic}[1] %这个1 表示每一行都显示数字  
\REQUIRE ~~\\ %算法的输入参数：Input  
密钥（$key$）\\  
\STATE 生成替换表（$Sbox$）（$16\times 16$），用于加密
\STATE 生成反替换表（$InvSbox$）（$16\times 16$），用于解密
\STATE 生成轮常数表（$Rcon$）（$11\times 4$），用于加密
\STATE 执行密钥扩展（$KeyExpansion$）（$Nb*(Nr+1)\times 4$），用于加密 
\end{algorithmic}  
\end{algorithm}  
%-----------------------------------------