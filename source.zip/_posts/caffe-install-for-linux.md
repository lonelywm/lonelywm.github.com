title: Caffe Install For Linux
id: 143
categories:
  - Linux
  - Caffe
date: 2015-07-04 23:05:14
tags: 
- caffe
- deep learning

---

尝试在Ubuntu和Fedora成功配置了Caffe，后来觉得Fedora不好用，就只用ubuntu（没有安装CUDA，因为用的虚拟机嘛）

下面主要说下在Ubuntu14下的配置
<!--more-->

## 一、安装Caffe

安装官网的指引：首先安装依赖包  
	
	sudo apt-get install libprotobuf-dev libleveldb-dev libsnappy-dev libopencv-dev libboost-all-dev libhdf5-serial-dev
	sudo apt-get install libgflags-dev libgoogle-glog-dev liblmdb-dev protobuf-compiler


因为没有用GPU，用openblas更快，注意安装命令如下

注意该命令官网上没有给出，比较坑，还有如果用默认的ablas好像编译的时候需要手工设置路径而用openblas，在配置文件中是可以通过shall自动定位路径的，这样不容易出错

	sudo apt-get install libopenblas-dev


然后需要修改Makefile.config

需要设置CPU

设置openblas


	cp Makefile.config.example Makefile.config
	# Adjust Makefile.config (for example, if using Anaconda Python)
	make all
	make test
	make runtest


## 二、安装python

首先要

	make pycaffe

然后使用pip安装所有的依赖库

首先安装pip

	#执行前两条就可以了
	$ sudo apt-get install python-pip python-dev build-essential
	$ sudo pip install --upgrade pip
	$ sudo pip install --upgrade virtualenv

所有的依赖项都在 `caffe-master/python/requirements.txt`


	sudo pip install -r python/requirements.txt


啊，是不是速度有点慢？有时候还连接不上。。。换个国内镜像吧，先打开文件 ~/.pip/pip.conf，加入下面内容：

	[global]
	index-url = http://e.pypi.python.org/simple


还有其他源

	http://pypi.douban.com/ 豆瓣
	http://pypi.hustunique.com/ 华中理工大学
	http://pypi.sdutlinux.org/ 山东理工大学
	http://pypi.mirrors.ustc.edu.cn/ 中国科学技术大学

如果想手动指定源，可以在pip后面跟-i 来指定源，比如用豆瓣的源来安装web.py框架：

	pip install web.py -i http://pypi.douban.com/simple

不过最好还是先翻墙

* 安装过程中好像会出现些小问题，因为scikit会依赖scipy所以可以手动分开安装
* 注意如果pip编译安装失败，可以先用apt-get命令安装所有编译所需的库

我自己用pip安装scipy时出错，后来用apt-get安装了依赖库，下面的库可能有多的
	sudo apt-get install python-numpy python-scipy python-matplotlib ipython ipython-notebook python-pandas python-sympy python-nose

为了让IPython notebook工作，还还需要安装tornado和pyzmq：

	sudo pip install tornado
	sudo apt-get install libzmq-dev
	sudo pip install pyzmq
	sudo pip install pygments
	sudo pip install jsonschema
	# 其中我系统默认安装了tornado，但是版本低了，需要升级
	sudo pip install --upgrade tornado


下面测试IPython notebook

	cd
	mkdir notebook
	cd notebook
	ipython notebook

看到浏览器启动了