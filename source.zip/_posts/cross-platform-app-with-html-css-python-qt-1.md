title: HTML+CSS+python+qtwebkit打造跨平台桌面应用（一）
id: 55
categories:
  - Python
date: 2015-05-08 18:47:18
tags:
---




## 引言

好的GUI能为程序增光添彩，但是设计出好的GUI并不是一件容易的事，一些大公司往往都有自己的GUI设计团队和定制的GUI解决方法，那么小公司或者个人呢？有没有廉价的、易学、通用的解决方案呢？大家可能首先想到的是MFC、WPF、C#等IDE自带的框架和控件库，也有人会说用wxWidget、QT等免费的第三方控件，而我认为HTML+CSS才是最通用、最低成本的解决方案。

我们的编程环境是GUI部分用qtwebkit，程序用python主要是为了快速开发。

<!--more-->
简单说一下HTML+CSS的优点

*   HTML+CSS是一套标准，注意是标准，不是哪个公司自己搞出来的，而是通用的，无论计算机如何发展，这套标准永远不会被淘汰（否则全世界的网站都要重新设计美工了），其实现在很多以前的框架都已经或者即将被淘汰，举例来说，比如微软吧，首先它的MFC早已经过时了，而WPF也即将被放弃（是微软自己放弃的，因为他又开发了新的东西，微软一直都是这么坑），所以我们学知识、用工具，要考虑到通用性和未来，没有人会愿意记住即将被淘汰的知识，然后又不得不重新学起。
*   HTML5+CSS3具有强大的表现力。
*   HTML+CSS是跨平台的，另外python和qt（qtwebkit）都是跨平台的，所以我们的程序也是跨平台的。
顺便提一下，好像现在也有不少用webkit做桌面级应用程序的框架，Inter开发了比较火的框架叫Node-Webkit，软件Wunderlist使用的一个开源的框架叫TideSDK（2012年发布的，好像好久没维护了，一直是beta版），国外还有收费的叫TideKit，还有好多吧。对于前两个我都尝试使用过，个人觉得那些被封装的太多，不靠谱（作为C++程序员，都力求知根知底），还有一点就是他们用Js写大部分逻辑，所以你的源码是暴露的，另外Js的执行效率也不得不考虑。

## 环境配置

安装环境的配置

*   python2.7（当然也可是3.4） [下载](https://www.python.org/downloads/)
*   pyqt  [下载](http://sourceforge.net/projects/pyqt/files/)
*   eclipse  [下载](http://www.eclipse.org/downloads/) （需配置python的环境 baidu上很多）
注意区分32位和64位的，安装时要对应

## 实现：HelloWorld
```
from PyQt4 import QtGui, QtWebKit

class myWindow(QtWebKit.QWebView):
    def __init__(self, parent=None):
        super(myWindow, self).__init__(parent)
        self.resize(400, 200)
        self.setHtml("QtWebKit + Hello Pythonlt")

if __name__ ==__main__:
    import sys
    app = QtGui.QApplication(sys.argv)
    main = myWindow()
    main.show()
    sys.exit(app.exec_())
```

![helloworld](../cross-platform-app-with-html-css-python-qt-1/1.png)