title: 最精简的Git新手入门
categories:
- Git
date: 2015-11-9 22:42:56
tags:
- git
- guide
---
## 开始
这篇教程虽不是全原创但确是本人整理得来的，一篇博客能写完，所以说足够精简，包括Git的主要内容和大部分命令
<!--more-->

## Git的起源
因为Linus坚定地反对CVS和SVN，这些集中式的版本控制系统不但速度慢，而且必须联网才能使用。有一些商用的版本控制系统，虽然比CVS、SVN好用，但那是付费的，和Linux的开源精神不符。

不过，到了2002年，Linux系统已经发展了十年了，代码库之大让Linus很难继续通过手工方式管理了，社区的弟兄们也对这种方式表达了强烈不满，于是Linus选择了一个商业的版本控制系统BitKeeper，BitKeeper的东家BitMover公司出于人道主义精神，授权Linux社区免费使用这个版本控制系统。



安定团结的大好局面在2005年就被打破了，原因是Linux社区牛人聚集，不免沾染了一些梁山好汉的江湖习气。开发Samba的Andrew试图破解BitKeeper的协议（这么干的其实也不只他一个），被BitMover公司发现了（监控工作做得不错！），于是BitMover公司怒了，要收回Linux社区的免费使用权。

Linus可以向BitMover公司道个歉，保证以后严格管教弟兄们，嗯，这是不可能的。实际情况是这样的：

Linus花了两周时间自己用C写了一个分布式版本控制系统，这就是Git！一个月之内，Linux系统的源码已经由Git管理了！牛是怎么定义的呢？大家可以体会一下。

Git迅速成为最流行的分布式版本控制系统，尤其是2008年，GitHub网站上线了，它为开源项目免费提供Git存储，无数开源项目开始迁移至GitHub，包括jQuery，PHP，Ruby等等。

## Git的优势
### 集中式vs分布式
- 集中式版本控制系统最大的毛病就是必须联网才能工作。
- 分布式版本控制系统不需要联网，每个人独立工作，然后需要汇总的时候再联网。

### 版本管理系统的三大功能
- 快速备份与恢复 （stage）
- 快速开发 （branch）
- 团队协作 （repository & branch）

## 安装GIt
### Ubuntu （Debian）
	$ sudo apt-get install git
### Centos （RedHat）
	$ sudo yum install git
	$ sudo rpm -ivh git-****.rpm  #直接从本地安装包安装

## 初始化Git
### 主要有两种方法
- 在本地新建一个git项目，然后将其推送到仓库（repository）
- 直接clone远程的git项目到本地，并继续开发

### 本地新建git项目

	$ cd newproject  #每个git项目对应一个目录
	$ git init  #init 后在目录中新建一个.git文件夹，来控制版本库

	# 如果你有远程仓库（比如在github上）可以为这个项目添加远程仓库
	$ git remote add origin git@github.com:michaelliao/learngit.git

### clone远程项目
	$ git clone git@github.com:michaelliao/gitskills.git   #克隆的项目默认具备远程仓库

## 最基本的操作
	$ git add readme.txt
	$ git commit -m "append GPL"

### 工作区与暂存区（Working Directory And Stage）
- 工作区就是你在电脑里能看到的目录
- 第一步是用git add把文件添加进去，实际上就是把文件修改添加到暂存区；
- 第二步是用git commit提交更改，实际上就是把暂存区的所有内容提交到当前分支。
	+ 因为我们创建Git版本库时，Git自动为我们创建了唯一一个master分支，所以，现在，git commit就是往master分支上提交更改。

### 管理修改
为什么Git比其他版本控制系统设计得优秀，因为Git跟踪并管理的是修改，而非文件。

你会问，什么是修改？比如你新增了一行，这就是一个修改，删除了一行，也是一个修改，更改了某些字符，也是一个修改，删了一些又加了一些，也是一个修改，甚至创建一个新文件，也算一个修改。

	$ git status
	# On branch master
	# Changes not staged for commit:
	#   (use "git add <file>..." to update what will be committed)
	#   (use "git checkout -- <file>..." to discard changes in working directory)
	#
	#    modified:   readme.txt
	#
	no changes added to commit (use "git add" and/or "git commit -a")
git status命令可以让我们时刻掌握仓库当前的状态，上面的命令告诉我们，readme.txt被修改过了，但还没有准备提交的修改。

	$ git diff readme.txt 
	diff --git a/readme.txt b/readme.txt
	index 46d49bf..9247db6 100644
	--- a/readme.txt
	+++ b/readme.txt
	@@ -1,2 +1,2 @@
	-Git is a version control system.
	+Git is a distributed version control system.
	 Git is free software.

git diff顾名思义就是查看difference，显示的格式正是Unix通用的diff格式，可以从上面的命令输出看到，我们在第一行添加了一个“distributed”单词。

**所以需要特别注意文档的编码格式**

首先这里再明确一下，所有的版本控制系统，其实只能跟踪文本文件的改动，比如TXT文件，网页，所有的程序代码等等，Git也不例外。版本控制系统可以告诉你每次的改动，比如在第5行加了一个单词“Linux”，在第8行删了一个单词“Windows”。而图片、视频这些二进制文件，虽然也能由版本控制系统管理，但没法跟踪文件的变化，只能把二进制文件每次改动串起来，也就是只知道图片从100KB改成了120KB，但到底改了啥，版本控制系统不知道，也没法知道。

不幸的是，Microsoft的Word格式是二进制格式，因此，版本控制系统是没法跟踪Word文件的改动的，前面我们举的例子只是为了演示，如果要真正使用版本控制系统，就要以纯文本方式编写文件。

因为文本是有编码的，比如中文有常用的GBK编码，日文有Shift_JIS编码，如果没有历史遗留问题，强烈建议使用标准的UTF-8编码，所有语言使用同一种编码，既没有冲突，又被所有平台所支持。

**使用Windows的童鞋要特别注意**

千万不要使用Windows自带的记事本编辑任何文本文件。原因是Microsoft开发记事本的团队使用了一个非常弱智的行为来保存UTF-8编码的文件，他们自作聪明地在每个文件开头添加了0xefbbbf（十六进制）的字符，你会遇到很多不可思议的问题，比如，网页第一行可能会显示一个“?”，明明正确的程序一编译就报语法错误，等等，都是由记事本的弱智行为带来的。建议你下载Notepad++代替记事本，不但功能强大，而且免费！记得把Notepad++的默认编码设置为UTF-8 without BOM即可：




### 撤销修改
	git checkout -- file
命令git checkout -- readme.txt意思就是，把readme.txt文件在工作区的修改全部撤销，这里有两种情况：

一种是readme.txt自修改后还没有被放到暂存区，现在，撤销修改就回到和版本库一模一样的状态；

一种是readme.txt已经添加到暂存区后，又作了修改，现在，撤销修改就回到添加到暂存区后的状态。

总之，就是让这个文件回到最近一次git commit或git add时的状态。
### 删除文件
- 直接在文件管理器中把没用的文件删了
- 用rm命令

## 杀手锏武器：分支（branch）
分支在实际中有什么用呢？假设你准备开发一个新功能，但是需要两周才能完成，第一周你写了50%的代码，如果立刻提交，由于代码还没写完，不完整的代码库会导致别人不能干活了。如果等代码全部写完再一次提交，又存在丢失每天进度的巨大风险。

现在有了分支，就不用怕了。你创建了一个属于你自己的分支，别人看不到，还继续在原来的分支上正常工作，而你在自己的分支上干活，想提交就提交，直到开发完毕后，再一次性合并到原来的分支上，这样，既安全，又不影响别人工作。

所以我们在github上看到的大一点项目基本都有分支，常见的有master分支，还有一个开发版dev，还有一个分布式版parallel

### 分支的作用
当我们创建新的分支，例如dev时，Git新建了一个指针叫dev，指向master相同的提交，再把HEAD指向dev，就表示当前分支在dev上。Git创建一个分支很快，因为除了增加一个dev指针，改改HEAD的指向，工作区的文件都没有任何变化！

不过，从现在开始，对工作区的修改和提交就是针对dev分支了，比如新提交一次后，dev指针往前移动一步，而master指针不变：

![b1](../git-gettng-start/b1.png)
![b1](../git-gettng-start/b2.png)

假如我们在dev上的工作完成了，就可以把dev合并到master上。Git怎么合并呢？最简单的方法，就是直接把master指向dev的当前提交，就完成了合并：

![b1](../git-gettng-start/b3.png)

所以Git合并分支也很快！就改改指针，工作区内容也不变！

合并完分支后，甚至可以删除dev分支。删除dev分支就是把dev指针给删掉，删掉后，我们就剩下了一条master分支：

![b1](../git-gettng-start/b4.png)

### 举例说明
	$ git checkout -b dev
	Switched to a new branch 'dev'

`git checkout`命令加上`-b`参数表示创建并切换，相当于以下两条命令：

	$ git branch dev
	$ git checkout dev
	Switched to branch 'dev'

然后，用`git branch`命令查看当前分支：

	$ git branch
	* dev
	  master

`git branch`命令会列出所有分支，当前分支前面会标一个*号。

然后，我们下面的所有工作就都是在dev分支上进行的了。

	$ git add readme.txt 
	$ git commit -m "branch test"
	[dev fec145a] branch test
	 1 file changed, 1 insertion(+)

现在，`dev`分支的工作完成，我们就可以切换回`master`分支：

	$ git checkout master
	Switched to branch 'master'

![b1](../git-gettng-start/b5.png)

现在，我们把`dev`分支的工作成果合并到`master`分支上：

	$ git merge dev
	Updating d17efd8..fec145a
	Fast-forward
	 readme.txt |    1 +
	 1 file changed, 1 insertion(+)

git merge命令用于合并指定分支到当前分支。合并后，再查看readme.txt的内容，就可以看到，和dev分支的最新提交是完全一样的。

注意到上面的Fast-forward信息，Git告诉我们，这次合并是“快进模式”，也就是直接把master指向dev的当前提交，所以合并速度非常快。

当然，也不是每次合并都能Fast-forward（当没有冲突时可以），我们后面会将其他方式的合并。

合并完成后，就可以放心地删除dev分支了：

### 解决冲突
![m1](../git-gettng-start/m1.png)

	$ git merge feature1
	Auto-merging readme.txt
	CONFLICT (content): Merge conflict in readme.txt
	Automatic merge failed; fix conflicts and then commit the result.

果然冲突了！Git告诉我们，readme.txt文件存在冲突，必须手动解决冲突后再提交。git status也可以告诉我们冲突的文件：

	$ git status
	# On branch master
	# Your branch is ahead of 'origin/master' by 2 commits.
	#
	# Unmerged paths:
	#   (use "git add/rm <file>..." as appropriate to mark resolution)
	#
	#       both modified:      readme.txt
	#
	no changes added to commit (use "git add" and/or "git commit -a")

我们可以直接查看readme.txt的内容：

	Git is a distributed version control system.
	Git is free software distributed under the GPL.
	Git has a mutable index called stage.
	Git tracks changes of files.
	<<<<<<< HEAD
	Creating a new branch is quick & simple.
	=======
	Creating a new branch is quick AND simple.
	>>>>>>> feature1
	
修改文件并commit

	$ git add readme.txt 
	$ git commit -m "conflict fixed"
	[master 59bc1cb] conflict fixed

再次合并分支

![m2](../git-gettng-start/m2.png)

最后，删除`feature1`分支：

	$ git branch -d feature1
	Deleted branch feature1 (was 75a857c).

### 分支命令
Git鼓励大量使用分支：

查看分支：`git branch`

创建分支：`git branch <name>`

切换分支：`git checkout <name>`

创建+切换分支：`git checkout -b <name>`

合并某分支到当前分支：`git merge <name>`

删除分支：`git branch -d <name>`

## 多人协作与远程仓库
当你从远程仓库克隆时，实际上Git自动把本地的master分支和远程的master分支对应起来了，并且，远程仓库的默认名称是origin。

### 跟踪
本地的一个分支会对应一个远程分支，跟踪就是方便我们push和pull，（master是自动跟踪的）

跟踪的命令`track`

	git branch --track dev origin/dev

### 查看
要查看远程库的信息，用git remote：

	$ git remote
	origin
或者，用git remote -v显示更详细的信息：

	$ git remote -v
	origin  git@github.com:michaelliao/learngit.git (fetch)
	origin  git@github.com:michaelliao/learngit.git (push)

### 推送

推送分支，就是把该分支上的所有本地提交推送到远程库。推送时，要指定本地分支（track过的不用），这样，Git就会把该分支推送到远程库对应的远程分支上：

	$ git push origin master
如果要推送其他分支，比如dev，就改成：

	$ git push origin dev
但是，并不是一定要把本地分支往远程推送，那么，哪些分支需要推送，哪些不需要呢？

### 冲突
然后如果远程的仓库被改动过了，则我们不能push到仓库，这个时候首先要pull抓回来，然后再本地合并分支，没有冲突以后再push到仓库

	git pull origin master

## 注意事项

### ignore文件
git项目可以在根目录下放一个.gitignore的文件，从名字上我们可以看出是一个忽略列表。通常我们需要配置这个文件，使git只包含我们项目中的源代码，比如一个c++项目，我们只需要包含.cpp .h 还有makefile文件，其他中间文件和最终的可执行文件都不用包含在我们的项目中。所以我们在建立git项目的时候一般需要有这么几个文件夹，src,include,bin,obj,lib，在配置makefile的时候最好这样规划。另外lib和include因为是共有的，最好统一配置。

### 权限问题
在配置远程仓库的时候，因为用ssh协议传输，需要配置ssh权限
git-gui->help->show ssh key=>将生成的密钥发给服务器，然后服务器添加到当前git用户的.ssh目录下的authorized_keys文件中即可