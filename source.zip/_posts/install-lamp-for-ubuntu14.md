title: LAMP配置+ftp（以Ubuntu14为例）
id: 278
categories:
  - Linux
  - Ubuntu
date: 2015-10-01 00:21:50
tags:
---

安装很简单，几个命令搞定

	sudo apt-get update
	sudo apt-get install apache2
	sudo apt-get install php5 
	sudo apt-get install mysql-server
	sudo chmod 777 /var/www

一些常用的

	apt-get install php5-gd
	sudo apt-get install php5-mysql

<!--more-->

## 1、设置密码

在新安装好Linux系统之后，想要用su root切换到root用户却不知道密码是什么，这个让人很惆怅刚安装好的Linux系统没有设置root用户密码的，下边介绍如何设置root用户的密码

第一步：sudo passwd
第二步：输入密码
第三步：确认密码

这样三个步骤过后root用户的密码就设置好了
切入root用户， su root 输入刚刚设置好的密码就可以了

## 2、创建用户及密码修改

若修改root自己的密码，直接输入 passwd 然后输入两次密码即可。
若修改其他用户，如oracle 的密码，可直接输入passwd oracle 输入两遍性新密码即可。

## 3、使用vim

学会使用vim很有必要，尤其是当通过远程管理linux主机的时候，因为此时无法用gedit等GUI软件，只能使用这种基于命令行的文本编辑器

vi有三种模式：
(1)一般模式：进入vi的默认模式，能够进行复制、黏贴、删除等操作；
(2)编辑模式：从一般模式按下‘i’即可进入；
(3)命令行模式：从一般模式按下“:”、'?'、'/'即可进入；

注意：如果安装了vim后，输入vi后也是使用vim编辑器，我们输入alias后看到“alias vi='vim'”；

“命令行模式”的常用按键

	:w  保存
	:q  退出vim
	:wq  保存并退出
	:wq!  （在可以转换权限的情况下）强制保存并退出
	:q!  直接退出不保存
	:w filename  另存为filename
	:n,m w filename  将第n行到第m行另存为filename
	:set nu  显示行号
	:set nonu  不显示行号
	:! command  暂时离开vim，并执行command，执行完后再进入vim
	:r filename  将filename文件的数据读入当前文件
	:set all  显示当前vim的环境配置

## 4、创建ftp

4.1 Ubuntu 下安装FTP软件当然选择大名鼎鼎的vsftpd（very secure FTP daemon）， Ubuntu装vsftpd很简单，一句命令就行：

	sudo rm /etc/pam.d/vsftpd（在ubuntu14中请先执行这一条，若没有执行可能会报错，后面第4点会提到）
	sudo apt-get install vsftpd


命令执行过程中，安装程序会给本地创建一个名为“ftp”的用户组，命令执行完之后会自动启动FTP服务。
可以使用“netstat -tl”命令检查FTP端口有没有已经打开，或者直接在浏览器里输入“ftp://你的服务器IP”（新安装的vsftpd默认是可以匿名不需要密码直接访问），如果能直接连接到FTP服务器，则安装vsftpd算是大功告成。

4.2 开启、停止、重启vsftpd服务也很简单：

	service vsftpd start | stop | restart


4.3 新安装的vsftpd默认是可以匿名访问，如果只想给某一个用户专门访问某一目录下的权限，则需要修改vsftpd的配置了。
首先，创建一个专门用来访问的用户，例如叫“test”：

	mkdir -p /home/test
	sudo useradd -g ftp -d /home/test -M test   (这里关键就是选取你要的目录为ftp的根目录/home/test，注意根目录是没有写入权限的，这个后面会提到)

解释一下useradd：
ftp代表用户组是ftp，必须设定
-g initial_group　group名称或以数字来做为使用者登入起始群组(group)。群组名须为现有存在的名称。
-d 是在指定的目录下进行建立如；
-M是不建立使用者目录，即使/etc/login.defs系统档设定要建立使用者目录

PS: 删除用户用以下命令：


sudo userdel test 


设置密码:


passwd test


修改vsftpd的配置文件“vi /etc/vsftpd.conf”：


#禁止匿名访问
anonymous_enable=NO
#接受本地用户
local_enable=YES
#可以上传
#chroot_local_user=YES
(解释：chroot_local_user=YES将所有用户限定在主目录内，chroot_list_enable=YES表示要启用chroot_list_file, 因为chroot_local_user=YES，即全体用户都被“限定在主目录内”,所以总是作为“例外列表”的chroot_list_file这时列出的是那些“不会被限制在主目录下”的用户。)
write_enable=YES
local_umask=022
#启用在chroot_list_file的用户只能访问根目录
chroot_list_enable=YES
chroot_list_file=/etc/vsftpd.chroot_list


在/etc/vsftpd.chroot_list添加受访问目录限制的用户：


echo test &gt;&gt; vi /etc/vsftpd.chroot_list


可以在本地测试ftp
命令：ftp 127.0.0.1
输入当前用户的密码后显示 >ftp
输入 bye 或者 quit 可以退出ftp

“500 OOPS: vsftpd: refusing to run with writable root inside chroot()”

启用了chroot的话，根目录要设置为不可写，这是vsftp的保护机制。


chmod a-w /home/test


那么用户登陆FTP就可以访问到test下的东西，但是没法去上传文件。如果把test文件夹设置成777权限，那么FTP就登陆不上去。

所以解决办法是。在test文件夹下再创建一个文件夹“/home/test/wwwroot”，将wwwroot设置成777就可以了，那么以后上传东西就上传到wwwroot里。

OK，重启vsftpd之后就可以使用上面新创建的账号访问。

4.4 但是使用ftp 命令登陆的时候总是提示如下的错误


root@server:~# ftp localhost
Connected to localhost.
220 (vsFTPd 2.3.5)
Name (localhost:root): ubuntu
331 Please specify the password.
Password:
530 Login incorrect.
Login failed.


于是我在网上搜了下看看大家都是怎么解决的，最后终于找到了解决的办法


sudo apt-get remove vsftpd
sudo rm /etc/pam.d/vsftpd
sudo apt-get install vsftpd  


这是因为ubuntu启用了PAM,所在用到vsftp时需要用到 /etc/pam.d/vsftpd 这个文件（默认源码安装的不会有这个文件），因此除了匿名用户外本地用户无法登录。所以只要删除了就可以了。

4.5 修改ftp的目录

## 5、配置Mysql

5.1 在安装mysql的时候会设置一个初始的用户名和密码比如用户名可以上root，但是注意这个root不是系统的root
首先用初始密码登陆
mysql -h localhost -u root -p123   （密码是123，密码前面必须有一个p，而且必须连在一起）(注意有些时候localhost无法连接，需要换成127.0.0.1)

5.2 我们可以修改密码：
方法一：


mysql&gt;set password =password(&#039;你的密码&#039;);
mysql&gt;flush privileges;


方法二.使用GRANT语句


mysql&gt;grant all on *.* to &#039;root&#039;@&#039;localhost&#039; IDENTIFIED BY &#039;你的密码&#039;with grant option ;
mysql&gt;flush privileges;


方法三.进入mysql库修改user表


mysql&gt;use mysql;
mysql&gt;update user set password=password(&#039;你的密码&#039;) where user=&#039;root&#039;; 
mysql&gt;flush privileges;


5.3 MySQL 连接远程数据库（192.168.0.201），端口“3306”，用户名为“root”，密码“123”


C:&gt;mysql -h 192.168.0.201 -P 3306 -u root -p123


赋予远程权限
在Ubuntu下需要首先：（为什么，不知道）
在目录/etc/mysql下找到my.cnf，用vim编辑，找到my.cnf里面的

bind-address           = 127.0.0.1
在mysql的命令行下面输入：


grant all privileges on databasename.* to root@120.00.00.00 identified by &#039;123456mima&#039;;   （databasename：是数据库名，也可以改为*，120.00.00.00，是你的ip，root是你的mysql用户名，）方法其实还用很多种，这种比较简单


比如更高权限的 grant all PRIVILEGES on _._ to admin@&#039;%&#039; identified by &#039;123456&#039;;  就是赋予了所有的数据库权限，用户名为admin，对于所有ip可以访问，密码123456.
flush privileges;

## 6、附件一些其他模块的安装

6.1 curl_init — 初始化一个cURL会话
解决办法：
1，安装php5-curl模块，默认路径会在/etc/php5/路径下


sudo apt-get install php5-curl


2，重启Apache服务器加载curl模块


sudo service apache restart   #或者是 sudo service apache2 restart


3，刷新。OK
7、附加一些常用命令


unzip file.zip  解压缩
cp -f -r /home/ftp/www/ /var/www/   直接覆盖的copy，不提示


## 7、一些错误的解决方法

### 1 apache2


Starting web server apache2   
apache2: Could not reliably determine the server&#039;s fully qualified domain name, 
... waiting apache2: Could not reliably determine the server&#039;s fully qualified domain name, using 127.0.1.1 for ServerName



vim /etc/apache2/apache2.conf


在最下面添加一行：ServerName localhost:80

### ftp 登陆不上

linux FTP 链接不上，错误提示：服务器无法识别命令。请使用原始ftp“HELP”来识别服务器所支持的所有命令。

点击详细错误的时候是下面的提示
vsftpd: refusing to run with writable root inside chroot() 错误的解决办法
一下是解决办法：
为了避免一个安全漏洞，从 vsftpd 2.3.5 开始，chroot 目录必须不可写。使用命令：
&#039;&#039;&#039;
 chmod a-w /home/user
&#039;&#039;&#039;
user 为FTP所连接的目录

## 8、一些设置选项

### 1、apache的网站路径配置


sudo vim /etc/apache2/sites-enabled/000-default.conf


找到这一行


 DocumentRoot /home/mysite


设置权限 不允许访问没有index.*文件的目录


<Directory /var/www/html>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
</Directory>



<Directory /var/www/html>
        Options FollowSymLinks
        AllowOverride None
        Require all granted
</Directory>


## 附录

### apache2开启htaccess

-  终端运行
sudo a2enmod
程序提示可供激活的模块名称，输入：
rewrite
成功会提示 rewrite already load
- 修改/etc/apache2/sites-enabled/000-default (该链接指向的是站点配置文件)
把（默认的www目录、或者需要应用.htaccess的目录）下的**AllowOverride 属性改为All**，保存。
例如：
```
DocumentRoot "/var/www"  
<Directory />  
    Options FollowSymLinks  
    AllowOverride All  
</Directory>  
<Directory "/var/www">  
    Options Indexes FollowSymLinks ExecCGI Includes  
    AllowOverride All  
    Order allow,deny  
    Allow from all  
</Directory>  
```
- apache2几个配置文件的关系 ：
apache2.conf  内部依次调用`httpd.conf`，`conf.d/` ，`sites-enabled/`配置的时候可灵活处理


### etc/vsftpd.conf 配置信息vs

```
# Example config file /etc/vsftpd.conf
#
# The default compiled in settings are fairly paranoid. This sample file
# loosens things up a bit, to make the ftp daemon more usable.
# Please see vsftpd.conf.5 for all compiled in defaults.
#
# READ THIS: This example file is NOT an exhaustive list of vsftpd options.
# Please read the vsftpd.conf.5 manual page to get a full idea of vsftpd's
# capabilities.
#
#
# Run standalone?  vsftpd can run either from an inetd or as a standalone
# daemon started from an initscript.
listen=YES
#
# Run standalone with IPv6?
# Like the listen parameter, except vsftpd will listen on an IPv6 socket
# instead of an IPv4 one. This parameter and the listen parameter are mutually
# exclusive.
#listen_ipv6=YES
#
# Allow anonymous FTP? (Disabled by default)
anonymous_enable=NO
#
# Uncomment this to allow local users to log in.
local_enable=YES
#
# Uncomment this to enable any form of FTP write command.
write_enable=YES
#
# Default umask for local users is 077\. You may wish to change this to 022,
# if your users expect that (022 is used by most other ftpd's)
#local_umask=022
#
# Uncomment this to allow the anonymous FTP user to upload files. This only
# has an effect if the above global write enable is activated. Also, you will
# obviously need to create a directory writable by the FTP user.
#anon_upload_enable=YES
#
# Uncomment this if you want the anonymous FTP user to be able to create
# new directories.
#anon_mkdir_write_enable=YES
#
# Activate directory messages - messages given to remote users when they
# go into a certain directory.
dirmessage_enable=YES
#
# If enabled, vsftpd will display directory listings with the time
# in  your  local  time  zone.  The default is to display GMT. The
# times returned by the MDTM FTP command are also affected by this
# option.
use_localtime=YES
#
# Activate logging of uploads/downloads.
xferlog_enable=YES
#
# Make sure PORT transfer connections originate from port 20 (ftp-data).
connect_from_port_20=YES
#
# If you want, you can arrange for uploaded anonymous files to be owned by
# a different user. Note! Using root for uploaded files is not
# recommended!
#chown_uploads=YES
#chown_username=whoever
#
# You may override where the log file goes if you like. The default is shown
# below.
#xferlog_file=/var/log/vsftpd.log
#
# If you want, you can have your log file in standard ftpd xferlog format.
# Note that the default log file location is /var/log/xferlog in this case.
#xferlog_std_format=YES
#
# You may change the default value for timing out an idle session.
#idle_session_timeout=600
#
# You may change the default value for timing out a data connection.
#data_connection_timeout=120
#
# It is recommended that you define on your system a unique user which the
# ftp server can use as a totally isolated and unprivileged user.
#nopriv_user=ftpsecure
#
# Enable this and the server will recognise asynchronous ABOR requests. Not
# recommended for security (the code is non-trivial). Not enabling it,
# however, may confuse older FTP clients.
#async_abor_enable=YES
#
# By default the server will pretend to allow ASCII mode but in fact ignore
# the request. Turn on the below options to have the server actually do ASCII
# mangling on files when in ASCII mode.
# Beware that on some FTP servers, ASCII support allows a denial of service
# attack (DoS) via the command SIZE /big/file in ASCII mode. vsftpd
# predicted this attack and has always been safe, reporting the size of the
# raw file.
# ASCII mangling is a horrible feature of the protocol.
#ascii_upload_enable=YES
#ascii_download_enable=YES
#
# You may fully customise the login banner string:
ftpd_banner=Welcome to linuxidc's FTP service.
#
# You may specify a file of disallowed anonymous e-mail addresses. Apparently
# useful for combatting certain DoS attacks.
#deny_email_enable=YES
# (default follows)
#banned_email_file=/etc/vsftpd.banned_emails
#
# You may restrict local users to their home directories.  See the FAQ for
# the possible risks in this before using chroot_local_user or
# chroot_list_enable below.
#chroot_local_user=YES
#
# You may specify an explicit list of local users to chroot() to their home
# directory. If chroot_local_user is YES, then this list becomes a list of
# users to NOT chroot().
# (Warning! chroot'ing can be very dangerous. If using chroot, make sure that
# the user does not have write access to the top level directory within the
# chroot)
#chroot_local_user=YES
chroot_list_enable=YES
# (default follows)
chroot_list_file=/etc/vsftpd.chroot_list
#
# You may activate the -R option to the builtin ls. This is disabled by
# default to avoid remote users being able to cause excessive I/O on large
# sites. However, some broken FTP clients such as ncftp and mirror assume
# the presence of the -R option, so there is a strong case for enabling it.
#ls_recurse_enable=YES
#
# Customization
#
# Some of vsftpd's settings don't fit the filesystem layout by
# default.
#
# This option should be the name of a directory which is empty.  Also, the
# directory should not be writable by the ftp user. This directory is used
# as a secure chroot() jail at times vsftpd does not require filesystem
# access.
secure_chroot_dir=/var/run/vsftpd/empty
#
# This string is the name of the PAM service vsftpd will use.
pam_service_name=vsftpd
#
# This option specifies the location of the RSA certificate to use for SSL
# encrypted connections.
rsa_cert_file=/etc/ssl/certs/ssl-cert-snakeoil.pem
# This option specifies the location of the RSA key to use for SSL
# encrypted connections.
rsa_private_key_file=/etc/ssl/private/ssl-cert-snakeoil.key
#
local_root=/home/linuxidc/公共的/FTP共享文件
```