title: Linux常用软件的安装
id: 360
categories:
- Linux
date: 2015-11-28 09:52:46
tags:
- linux
---

## 首先是输入法

sudo apt-get install fcitx-table-wbpy
在语言支持中将输入法设置为fcitx
<!--more-->

## 然后是浏览器

安装chrome

    #32位
    wget https://dl.google.com/linux/direct/google-chrome-stable_current_i386.deb
    #64位
    wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
    

    命令以64位为例

    sudo dpkg -i google-chrome-stable_current_amd64.deb

## 词典
首选有道词典，可惜官方的是要求ubuntu-14.04.10，我的版本不够，所以选择openyoudao，可以参考官网的安装方法`http://openyoudao.org`

Ubuntu/Debian: Add mirrorlist:

	deb http://ppa.launchpad.net/justzx2011/openyoudao-v0.4/ubuntu trusty main 
	deb-src http://ppa.launchpad.net/justzx2011/openyoudao-v0.4/ubuntu trusty main

shell:

	sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys  14C9B91C3F9493B9
	sudo apt-get update 
	sudo apt-get install openyoudao

### 未完待续