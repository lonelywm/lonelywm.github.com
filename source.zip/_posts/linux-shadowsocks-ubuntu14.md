title: ubuntu14下使用shadowsocks客户端
id: 297
categories:
- Linux
- Ubuntu
date: 2015-10-04 21:17:48
tags:
- linux
- ubuntu
- shadowsocks
---

现在翻墙的方法大概有三种
第一种是搬家，当然成本非常高
第二种是VPN，但是VPN比较贵，速度慢，而且人流高峰根本连不上
第三种是专属网络shadowsocks，速度快，很稳定。</p>

windows下和mac下很简单，直接下载软件即可，下面主要说一下linux下的使用
<!--more-->

## 配置shadowsocks

在linux下shadowsocks主要有5个版本， Python ，libev ，Go ， Nodejs，qt，其中前面4中是命令行操作的，只有qt是有gui界面的。
我只配置过python，go还有qt版，下面分别介绍一下这3个版本的使用。

### qt版

这个可以通过源码安装但是比较麻烦，因为还需要配置许多第三方库。推荐直接使用编译好的，命令如下：

```
#Ubuntu 14.04及更高版本
#添加ppa源
sudo add-apt-repository ppa:hzwhuang/ss-qt5
sudo apt-get update
sudo apt-get install shadowsocks-qt5 
```

启动shadowsocks-qt5

	sudo ss-qt5

然后可以直接在GUI界面中配置服务器

### python版

	sudo apt-get install python-pip
	pip install shadowsocks

新建一个配置文件ss_conf.json内容如下

```
{
    server:server_ip,
    server_port:443,
    local_address: 127.0.0.1,
    local_port:1080,
    password:password,
    timeout:300,
    method:aes-256-cfb,
    fast_open: false
}
```

启动方法：

	sslocal -c /home/username/Desktop/ss_conf.json


这个好像比较老了，这里还有一个更新的版本的
https://teddysun.com/342.html

### go版

参考
https://teddysun.com/392.html

## 转换HTTP代理

Shadowsocks默认是用Socks5协议的，对于Terminal的get,wget等走Http协议的地方是无能为力的，所以需要转换成Http代理，加强通用性，这里使用的转换方法是基于Polipo的。

输入命令安装Polipo：

	sudo apt-get install polipo


修改配置文件：

	sudo gedit /etc/polipo/config

将下面的内容整个替换到文件中并保存：

```
#This file only needs to list configuration variables that deviate
#from the default values.  See /usr/share/doc/polipo/examples/config.sample
#and polipo -v for variables you can tweak and further information.
logSyslog = false
logFile = /var/log/polipo/polipo.log
socksParentProxy = 127.0.0.1:1080
socksProxyType = socks5
chunkHighMark = 50331648
objectHighMark = 16384
serverMaxSlots = 64
serverSlots = 16
serverSlots1 = 32
proxyAddress = 0.0.0.0
proxyPort = 8123
```

重启Polipo：


	/etc/init.d/polipo restart


验证代理是否正常工作：


	export http_proxy=http://127.0.0.1:8123/
	curl www.google.com


如果正常，就会返回抓取到的Google网页内容。

另外，在浏览器中输入`http://127.0.0.1:8123/`便可以进入到Polipo的使用说明和配置界面。

## 配置浏览器

在firefox中`preference->advanced->network->connection->settings`中选择手动设置代理，并将http代理设置为127.0.0.1 端口8123  （就是之前第二步配置的port）

PS.如果跳过第二步，直接在第三部中配置http代理设置为127.0.0.1 端口1080，有些文章中是这样配置的，但是本人亲测这样无法连接上网。