title: Makefile模板
categories:
- Linux
date: 2015-11-25 22:40:11
tags:
- makefile
---

## Makefile模板

<!--more-->

```
##########################################################
#
#	Makefile 模版 
#
##########################################################

EXTENSION=cpp
TARGET=all

###################项目路径和程序名称#################################
#不要修改下面的路径

DIR= $(shell pwd)
BIN_DIR=$(DIR)/bin
LIB_DIR=$(DIR)/lib
SRC_DIR=$(DIR)/src
INCLUDE_DIR=$(DIR)/include
OBJ_DIR=$(DIR)/obj

###################OBJ文件及路径############################################

OBJS =$(patsubst $(SRC_DIR)/%.$(EXTENSION), $(OBJ_DIR)/%.o,$(wildcard $(SRC_DIR)/*.$(EXTENSION)))

###################include头文件路径##################################

INCLUDE=-I $(INCLUDE_DIR)

###################编译选项及编译器###################################

CXX=g++
CFLAGS=-Wall -W -g 
LDFLAGS=

###################编译目标###########################################

.PHONY: all clean rebuild 

all: bin/$(TARGET)

bin/$(TARGET):$(OBJS) 
	$(CXX) $^ -o  $@  
	@echo "succeed"


$(OBJ_DIR)/%.o:$(SRC_DIR)/%.cpp
	@if [ ! -d  $(BIN_DIR) ]; then mkdir $(BIN_DIR); fi
	@if [ ! -d  $(OBJ_DIR) ]; then mkdir $(OBJ_DIR); fi
	$(CXX) $(INCLUDE)  -g  -o $@  -c $< 

#静态库生成	
#bin/libtest.a:$(OBJ_DIR)/test.o
#	ar r bin/libtest.a $(OBJ_DIR)/test.o  
	
clean:
	rm -rf $(OBJS)
	rm -rf $(BIN_DIR)/$(TARGET)

rebuild: clean all 
```