title: 进程间通信之SendMessage/PostMessage
id: 45
categories:
  - Windows
date: 2015-05-01 08:53:38
tags:
- message

---
进程间通信之SendMessage/PostMessage的区别

<!--more-->
## 接收消息方：

```
define WM_MYMESSAGE WM_USER + 100 //不用括号
```
```
afx_msg LRESULT OnMyMessage(WPARAM wParam, LPARAM lParam);
```
```
BEGIN_MESSAGE_MAP(CMyWnd2, CWnd)
   ON_MESSAGE(WM_MYMESSAGE, OnMyMessage)
END_MESSAGE_MAP()
```

```
LRESULT CMyWnd2::OnMyMessage(WPARAM wParam, LPARAM lParam)
{
   // Handle message here.
   return 0;
}
```

## 发送方：

	int main()
	{
	    HWND hwnd = FindWindow(NULL,Name);
	    PostMessage(hwnd,WM_USER +100,NULL,NULL);  //SendMessage
	    return 0;
	}


## 备注：

- afx_msg 其实没有任何作用，去掉编译也是可以通过的，加上的好处就是让代码更具有可读性（别人就知道了这个函数是响应消息的）
- PostMessage与SendMessage的区别是：
PostMessage是在本进程的时间片内，发送消息并直接执行远程进程的响应函
SendMessage是将消息发送给远程进程，待轮到远程进程的时间片，远程进程自己执行取消息，执行消息响应函数
- 用户自定义消息必须声明为上述形式，声明成 afx_msg void 函数名() 是不对的