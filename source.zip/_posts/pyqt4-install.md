title: pyQt4 安装
id: 51
categories:
  - Python
date: 2015-05-04 22:35:09
tags:
- python
- qt
---

## 准备工作

qt是c++库，在python中使用这个库就必须要有接口，使用python能够调用C++代码，qt官方选择了sip这个python与qt的接口库。

在pyqt的官网上，http://www.riverbankcomputing.co.uk/software/pyqt/download/

可以找到sip下载链接：http://www.riverbankcomputing.co.uk/software/sip/download

## 现在安装pyqt4：

1. 安装python
2. 安装sip，将sip解压到了python的目录下，C:Python26Libsite-packages
3. 安装pyqt4，一路next，安装完成。

## 最后测试下：

```
import sys
from PyQt4.QtGui import *
a = QApplication(sys.argv)
w = QWidget()
w.resize(400,200)
w.setWindowTitle(Hello, World!)
w.show()
sys.exit(a.exec_())
```
