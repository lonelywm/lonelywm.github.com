title: QT自动打包依赖dll
id: 253
categories:
  - Qt
date: 2015-09-15 15:07:54
tags:
---

Qt Widgets Application的发布方式：
打开Qt命令行：

	windeployqt hellomw.exe
<!--more-->
另外还有Qt Quick Application的发布方式

`http://tieba.baidu.com/p/3730103947`