title: 'QT::QTableView的使用'
tags:
  - qtableview
  - tq
id: 224
categories:
  - Qt
date: 2015-08-04 09:12:48
---

QTableView采用的是类似MVC的内容与表现分离的设计模式

<!--more-->

## 使用方法

在MainWindow中为TableView添加Model,注意如果是局部变量要用new来申请,最好申请为类的私有成员变量


	ModelEx model;
	ui.tableView->;setModel(model);


.h文件

```
#ifndef MODELEX_H
#define MODELEX_H

#include
#include
#include
#include

class ModelEx : public QAbstractTableModel
{
    Q_OBJECT
public:
    explicit ModelEx(QObject *parent = 0);
    virtual int rowCount(const QModelIndex parent=QModelIndex()) const;
    virtual int columnCount(const QModelIndex parent=QModelIndex()) const;
    virtual QVariant data(const QModelIndex index, int role) const;
    virtual QVariant headerData(int section, Qt::Orientation orientation, int role) const;

signals:
public slots:
private:
    QVector army;
    QVector weaponType;
    QMap armyMap;
    QMap weaponTypeMap;
    QStringList  weapon;
    QStringList  header;
    void populateModel();
};
#endif // MODELEX_H
```

.cpp文件

```
#include "modelex.h"

ModelEx::ModelEx(QObject *parent) :
    QAbstractTableModel(parent)
{
    armyMap[1]=tr("空军");
    armyMap[2]=tr("海军");
    armyMap[3]=tr("陆军");
    armyMap[4]=tr("海军陆战队");
    weaponTypeMap[1]=tr("轰炸机");
    weaponTypeMap[2]=tr("战斗机");
    weaponTypeMap[3]=tr("航空母舰");
    weaponTypeMap[4]=tr("驱逐舰");
    weaponTypeMap[5]=tr("直升机");
    weaponTypeMap[6]=tr("坦克");
    header<<tr("军种")<<tr("种类")<<tr("武器");
    army<<1<<2<<3<<4<<2<<4<<3<<1;
    weaponType<<1<<3<<5<<7<<4<<8<<6<<2;
    weapon<<tr("B-2")<<tr("尼米兹级")<<
            ("阿帕奇")<<tr("黄蜂级")<<
            tr("阿利伯克级")<<tr("AAAV")<<
            tr("M1A1")<<tr("F-22");
}

int ModelEx::columnCount(const QModelIndex &parent) const
{
    return 3;
}

int ModelEx::rowCount(const QModelIndex &parent) const
{
    return army.size();
}

QVariant ModelEx::data(const QModelIndex &index, int role) const
{
    if(!index.isValid())
        return QVariant();

    if (role == Qt::TextAlignmentRole && index.column()!=1)  //除了第2列以外居中对齐
	return Qt::AlignCenter | Qt::AlignVCenter;

    if(role==Qt::DisplayRole)
    {
        switch(index.column())
        {
        case 0:
            return armyMap[army[index.row()]];
            break;
        case 1:
            return weaponTypeMap[weaponType[index.row()]];
            break;
        case 2:
            return weapon[index.row()];
        default:
            return QVariant();
        }
    }
    return QVariant();
}

QVariant ModelEx::headerData(int section, Qt::Orientation orientation, int role) const
{
    if(role==Qt::DisplayRole&&orientation==Qt::Horizontal)
        return header[section];
    return QAbstractTableModel::headerData(section,orientation,role);
}
```

## 常用设置

1.  居中对齐（可指定列）： 在data函数中实现；见代码
2.  水平表头自适应宽度： view->horizontalHeader()->sectionResizeMode(QHeaderView::Stretch);
3.  设置制定行（列）宽度： view->horizontalHeader()->resizeSection(0, 70);
4.  不显示表头：ui编辑器中设置
5.  拉伸最后一列：ui编辑器中设置

## 其他优化

因为ui编辑器自动生成的View类有很多属性设置不了，比如上面提到的“设置行宽度”但是如果把代码写到类外面有不符合“封装”的设计原则，所以我们可以把控制View的部分内容放到我们自定义的ViewModel中，见代码：

```
void ModelEx::initView(QTableView *view)
{
	view-&gt;horizontalHeader()-&gt;sectionResizeMode(QHeaderView::Stretch);
	view-&gt;horizontalHeader()-&gt;resizeSection(0, 70);
	view-&gt;horizontalHeader()-&gt;resizeSection(1, 270);
}
```

```
ModelEx model;
ui.tableView-&gt;setModel(model);
pCodeTableModel-&gt;initView(ui.tableView);
```