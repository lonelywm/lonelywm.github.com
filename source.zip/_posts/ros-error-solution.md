title: 配置ROS出现的问题及解决方法
id: 248
categories:
  - Ros
date: 2015-09-14 17:43:01
tags:
- ros
---

gazebo出现配置错误：

	sudo apt-get install libgazebo5-dev