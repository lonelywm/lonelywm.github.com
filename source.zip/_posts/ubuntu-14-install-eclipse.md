title: Ubuntu 14 配置eclipse
id: 140
categories:
  - Linux
date: 2015-07-04 22:58:38
tags:
---

在网上下载了eclipse-cpp-mars-R-linux-gtk-x86_64.tar

解压以后直接能用（在fedora上）但是在Ubuntu用不了

出现如下错误：
A Java Runtime Environment (JRE) or Java Development Kit (JDK) 
must be available in order to run Eclipse. No Java virtual machine 
was found after searching the following locations: 

所以要安装JDK JRE
<!--more-->

	#JAVA 环境安装
	在下面网址下载
	http://ghaffarian.net/downloads/Java/JDK/
	jdk-7u80-linux-x64.tar.gz  
	#或者 jdk-8u45-linux-x64.tar.gz
	sudo tar zxvf jdk-7u80-linux-x64.tar.gz  -C /usr/lib/jvm  

	#注意相对路径什么的自己改好

安装完毕还要设置环境变量
	#第一步
	打开终端并输入：
	sudo gedit ~/.bashrc
	输入密码
	
	#第二步
	在结尾加入
	export JAVA_HOME=/usr/lib/jvm/jdk1.7.0_80  
	export JRE_HOME=${JAVA_HOME}/jre   
	export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib   
	export PATH=${JAVA_HOME}/bin:$PATH

	#第三步 
	应用更改
	source ~/.bashrc

可以查看当前java版本 看看是不是安装上了`$ java -version` 

eclipse默认在自己的目录下找jre，可以把jre拷贝到eclipse目录下，这样比较笨重 简单建立一个软连接就可以解决： 

	$ cd <eclipse dir> 
	$ ln -sf $JRE_HOME jre 
	#目的是在eclipse安装目录下建立一个名称为jre的链接，将其指向java安装目录下的jre目录。