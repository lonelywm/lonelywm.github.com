title: Ubuntu常用shell整理
id: 152
categories:
  - Ubuntu
date: 2015-07-05 20:23:03
tags:
---

## 软件安装

有时候安装一些大的软件，因为网络太慢或其它原因放弃安装了，如果再继续安装其它软件的时候（apt-get）就会提示错误（sudo dpkg --configure -a 解决此问题）	

【解决方案一】
这个时候需要先apt-get clean，在su下，然后就可以了 apt-get clean

	#注意clean以后其实只是忽略错误软件，但是安装完毕一个软件后会提示是否继续，如果继续的话就会继续安装之前的有错误的软件

【解决方案二】
好像有时候apt-get clean无效，上面问题更好地解决方法：

	sudo pkill dpkg
	sudo rm /var/lib/dpkg/lock

【解决方案三（推荐）】
oracle-java7-installer安装java失败之后的处理 ：（这个方法切实可行）
sudo rm /var/lib/dpkg/info/oracle-java7-installer*
sudo apt-get purge oracle-java7-installer*
sudo rm /etc/apt/sources.list.d/*java*

## Shell命令

### Ubuntu下默认sh脚本 双击运行

1. ctrl-alt-t呼出控制台。
1. 输入dconf-editor，无需sudo，表示为当前用户配置。
1. 如果没有提供可用apt-get install dconf-editor 命令来获得
1. 出来一个窗口，找到这个键值路径`org.gnome.nautilus.preferences`，旗下有`executable-text-activation`个键值，默认是display，也就是开默认文本编辑器。改为ask。如果想改回去就点右下的，set to default，回复默认，默认是display。改后立刻生效。


### 常用shell
```
rm
rm-rf表示删除文件，而且可以删除非空目录。-rf参数表示递归强制删除
```

```
chmod +x ./:为文件增加可执行权限，往往通过U盘拷贝的文件都不具备执行权限
所以不具备写权限的文件 用sudo ./abc 是不会自动补全文件名的

touch :创建文件
gedit :用文本编辑器打开并编辑
mkdir examples/_temp
```

#Python
caffe用到的一些python库：

	sudo apt-get install python-yaml