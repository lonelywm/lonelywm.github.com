title: visual studio 静态库项目
id: 262
categories:
  - Windows
date: 2015-09-27 18:07:11
tags:
- static
- lib
---

##简介
visual studio 静态库项目的作用是生成lib文件，静态lib将导出声明和实现都放在lib中。编译后所有代码都嵌入到宿主程序，lib文件是不对外公开的，不能查看一个编译过后的文件.

<!--more-->

##制作lib
visual studio 新建项目 - win32项目 在应用程序类型选择时使用静态库（dll为动态库），一般情况下不要使用预编译头，像lua这类型的脚本语言，在使用visual studio生成lib的时候是不可以选择使用预编译头的，否则会报错。 在新建项目后，将需要用到的源代码添加到项目后生成即可得到lib文件。
*（建议把项目属性中得输出路径改为.bin，一个你容易找到的目录，这样生成的lib文件就会放入到这个文件夹中了。）*

##使用lib
两种方法：
1. 通过修改 项目属性 - 连接器 - 输入 - 附加依赖项去添加lib 
2. 加入预编译指令#pragma comment (lib,"*.lib")，这种方法优点是可以利用条件预编译指令链接不同版本的LIB文件。因为，在Debug方式下，产生的LIB文件是Debug版本，如Regd.lib；在Release方式下，产生的LIB文件是Release版本，如Regr.lib。