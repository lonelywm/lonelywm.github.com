title: 'vmware压缩磁盘空间的方法[转]'
id: 256
categories:
  - Windows
date: 2015-09-16 19:53:03
tags:
- vm
---

转自 http://blog.csdn.net/gzshun/article/details/8332047
<!--more-->
for linux
1、进入系统后，在GUI界面下启动 vmware-toolbox，选择shrink后根据图形提示选择partation压缩
**2、在shell里 `vmware-toolbox-cmd disk shrink /partation`** 亲测可用 将/partation 直接改为 /
3、如果和我一样进不了系统的，可以在本地压缩，要求安装了vmware，vmware目录vmware-vdiskmanager.exe -k f:vmwarerhrh6.vmdk （不能有快照）
fow windows
1、进虚拟机里面执行vmware-toolbox工具
2、采用linux 3的方法
另外在vmware社区还有人建议可以用

	vmkfstools -i old.vmdk new.vmdk -d thin