title: Windows批处理(bat)增加环境变量
id: 218
categories:
  - Windows
date: 2015-07-30 09:50:30
tags:
- windows
---

经常遇到安装完某个软件或者库，需要配置环境变量的情况，手动修改太麻烦，而且重装系统后还需要再次修改。有没有简单的方法呢？

当然有了，就是用批处理命令
<!--more-->

以下批处理仅在win7测试，xp未必能用

注意设置完环境变量需要重启生效

```
@echo off  
set _Path=%cd%
SETX PATH %PATH%;%_Path% /M
pause
```