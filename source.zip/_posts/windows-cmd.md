title: Windows常用cmd命令
id: 148
categories:
  - Windows
date: 2015-07-05 09:41:02
tags: 
- windows
- shell
---

计算机定时关机：

	shutdown -s -t 1800  //1800表示1800秒后  //取消：shutdown -a

计算机定时休眠的cmd命令怎么写：
	
	at 8:10 rundll32 powrprof.dll,SetSuspendState